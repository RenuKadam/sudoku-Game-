global userid
userid = sys.argv[1]
print(userid)